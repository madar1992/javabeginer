/*   JFM1T12_Assignment5:

     Write a program to build any collection containing duplicates. Create its copy with all duplicates removed. 
     Prompt the user input from the terminal.
     
     Sample Input:
     Enter how many numbers you want: 
     4
     Enter Number 0
     4
     Enter Number 1
     3
     Enter Number 2
      3
     Enter Number 3
     4
     
     Expected Output:
     After removing duplicates: [4, 3]
*/     
import java.util.*; 
import java.util.ArrayList; 

class Duplicate  { 

//main method
public static void main(String args[]){

//declare variables
    int i;

//create Scanner object
    Scanner sc= new Scanner(System.in);

//take input from user
    System.out.println("Enter how many numbers you want");
    int n=sc.nextInt();
//creat an object of LinkedHashSet class
     LinkedHashSet<Integer> set=new LinkedHashSet(); 
    for( i=0;i<n;i++)
    {
     System.out.println("Enter number "+i);
     int num=sc.nextInt();
     set.add(num);
    }

//creat an object of ArrayList class and pass LinkedHashSet object
    ArrayList<Integer> list1=new ArrayList<>();
    list1.addAll(set);
//Print result
    System.out.print("After removing duplicates: ");
    System.out.print(list1);
    }
}


