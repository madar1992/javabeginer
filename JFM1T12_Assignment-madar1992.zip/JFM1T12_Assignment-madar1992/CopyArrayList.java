/*   JFM1T12_Assignment3:

     Write a program to copy one arraylist into another.
     Prompt the user input from the terminal.
     
     Sample Input:
     Enter how many numbers you want: 
     5
     Enter Number 0
     5
     Enter Number 1
     4
     Enter Number 2
     3
     Enter Number 3
     2
     Enter Number 4
    
    Expected Output:
    -----Iterating over the second ArrayList----
     5
     4
     3
     2
     1

*/

import java.util.*; 
import java.util.ArrayList; 

class CopyArrayList  { 

//main method
  public static void main(String args[]){

//declare variables
  int i;

//create Scanner object
    Scanner sc= new Scanner(System.in);

//take input from user
    System.out.println("Enter how many numbers you want");
    int n=sc.nextInt();
    //creating a object
    ArrayList<Integer> list1=new ArrayList<>();
    // Using for loop
    for( i=0;i<=4;i++)
    {
     System.out.println("Enter number "+i);
     int num=sc.nextInt();
     list1.add(num);
    }

// Assign the first reference to second
     ArrayList<Integer> list2=new ArrayList<>();
     list2.addAll(list1);

// Iterat over second ArrayList and print
    Iterator itr=list2.iterator();
    //getting the Iterator
     System.out.println("-----Iterating over the second ArrayList----");
     //check if iterator has the elements
     while(itr.hasNext()){
     //printing the element and move to next
     System.out.println(itr.next()); 
     }  
   }
}


