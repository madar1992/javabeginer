package mypack;
 public class MyClass{
    public void display(){
        System.out.println("Welcome to Packages");
    }
}