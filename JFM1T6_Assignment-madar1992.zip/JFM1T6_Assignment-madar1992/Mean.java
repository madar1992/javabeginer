import java.util.Scanner;
public class Mean{
 public static void main(String[] args) {
  double sum = 0;
  double x = 1;
  Scanner sc = new Scanner(System.in);
  System.out.println("Enter number inputs you want pass : ");
  int n = sc.nextInt();
  while (x <= n) {
   System.out.println("number "  + (int) x  + ":");
   sum += sc.nextInt();
   x += 1;
  }
  double avgn = (sum / n);

  System.out.println("Mean :" + avgn);
 }
}