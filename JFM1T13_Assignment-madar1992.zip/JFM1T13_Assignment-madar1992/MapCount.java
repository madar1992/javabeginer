/*  JFM1T13_Assignment3:

      Write a Java program to count the number of key-value (size) mappings in a map. 
      Prompt the user input from the terminal.

      Sample Input: 
      Enter value:20
      Enter key:bitLabs
      Enter another student (y/n)?y
      Enter value:25
      Enter key:welcomes
      Enter another student (y/n)?y
      Enter value:30 
      Enter key:you
      Enter another student (y/n)?n

      Expected Output: The size of the map is 3
*/
import java.util.*;
import java.util.Scanner;
import java.util.HashMap;
public class MapCount {
      
      //main method
      public static void main(String args[]){
      boolean flag=true;
      //declare HashMap object
      HashMap<Integer,String> ma=new HashMap<Integer,String>();

      //create a while loop for user not enter no
      while(flag){

      //ask for user input for value and key
      Scanner sc=new Scanner(System.in);
      System.out.print("Enter value: ");
      Integer val=Integer.parseInt(sc.nextLine());
      
      System.out.print("Enter key: ");
      String key=sc.nextLine();
      
      //add the user inputs to the HashMap
      String newMa=ma.put(val,key);
      //ask user if they want to enter another
      
      System.out.print("Enter another student (y/n)? ");
      String cal=sc.nextLine();

      //condition to satisfy in order to loop again
      if (cal.equals("y")){
            flag=true;
      }
      else{
            flag=false;
            break;
      }
      }

      //print total size as result
      System.out.println("Size of the map is : "+ ma.size());

      
      }
}