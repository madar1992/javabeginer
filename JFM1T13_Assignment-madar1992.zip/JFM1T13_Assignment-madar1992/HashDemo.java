/*    JFM1T13_Assignment5:  

      Create an application having a Generic HashMap with Empcode  as key and EmpName as value. Display only EmpNames as output. 
       Prompt the user input from the terminal.

      Sample Input: 
      Enter Emp code:101
      Enter Emp Name: Ram
      Enter another student (y/n)?y
      Enter Emp code:102
      Enter Emp Name: Vaibhav
      Enter another student (y/n)?y
      Enter Emp code:103
      Enter Emp Name: Priyanka
      Enter another student (y/n)?n

      Expected Output: 
        Ram
        Vaibhav
        Priyanka
       
*/
import java.util.*;
import java.util.Scanner;
import java.util.HashMap;

public class HashDemo {
    
    //main method
    public static void main(String args[]){
    boolean flag=true;
    
    //declare the HashMap
    HashMap<Integer,String> mad=new HashMap<Integer,String>();
   

    //create a while loop for user not enter no
    while(flag){
        //ask for user input for value and key
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter Emp code:");
        Integer code=Integer.parseInt(sc.nextLine());
        
        
        System.out.print("Enter Emp Name:");
        String name=sc.nextLine();

        //add the user inputs to the HashMap
        String newVal = mad.put(code, name);
        
        //ask user if they want to enter another student details
        System.out.print("Enter another student (y/n)?");
        String cal=sc.nextLine();
        if (cal.equals("y")){
            
            flag=true;
        }
        else{
            flag=false;
        
        }
    }
   System.out.println();
    //use for each loop to grab Emp code and Emp Name
     for(Map.Entry m:mad.entrySet()){    
           System.out.println(m.getValue());    
          }  
    
    
    
}
}