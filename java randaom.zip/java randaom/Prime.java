import java.util.Scanner;
class Prime{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("ENTER STARTING NUMBER");
        int n1=sc.nextInt();
        
        System.out.println("ENTER ENDING NUMBER");
        int n2=sc.nextInt();
        int count=0;
        
        for(int i=n1;i<=n2;i++){
            for(int j=2;j<i;j++){
                if(i%j==0){
                    count=0;
                    break;
                }    
                else{
                    count=1;
                }
                
            }
            if(count==1){
                System.out.print(i+" ");
            }
        }
        
        
    }
}