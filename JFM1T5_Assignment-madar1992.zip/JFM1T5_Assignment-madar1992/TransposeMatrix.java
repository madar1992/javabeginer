/* JFM1T5_Assignment 4:

   Write a program to create a square matrix and print its transpose.
   Prompt the user input from the terminal.
   
  Sample Input:
  Enter number of rows: 3
  Enter number of columns: 3
  Elements  [1,1] : 2
  Elements  [1,2] : 3
  Elements  [1,3] : 4
  Elements  [2,1] : 1
  Elements  [2,2] : 2
  Elements  [2,3] : 3
  Elements  [3,1] : 4
  Elements  [3,2] : 5
  Elements  [3,3] : 6
   
  Expected Output:
    
  After Transpose Matrix  
  2       1       4
  3       2       5
  4       3       6
   
*/
import java.util.Scanner;

public class TransposeMatrix {

//Define the main method
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
//Declare the variables
System.out.println("Enter number of  rows:");
int row=sc.nextInt();
System.out.println("Enter number of  coloumns:");
int coloumn=sc.nextInt();
int[][] array=new int[row][coloumn];
//Take input from user to enter rows and column values
for(int i=0;i<row;i++)
{
    for(int j=0;j<coloumn;j++)
    {
        System.out.print("Elements ["+i+"]["+j+"] : ");
        array[i][j]=sc.nextInt();
    }
System.out.println(" ");

}
//Convert the square matrix into transpose
System.out.println("The above matrix before transpose");
for(int i=0;i<row;i++){
    for(int j=0;j<coloumn;j++)
    {
        System.out.print(array[i][j]+" ");
    }
        System.out.println(" ");
}
//Print the transpose matrix
System.out.println("The above matrix after transpose");
for(int i=0;i<coloumn;i++)
{
    for(int j=0;j<row;j++)
    {
        System.out.print(array[j][i]+" ");
        }
        System.out.println(" ");
}
//printing j and i instead of i and j
}
}