/* 
   JFM1T5_Assignment 5:
   Write a program to find and print the maximum element in a two-dimensional array with its index position.
   Prompt the user input from the terminal.
   
   Sample Input:
   Enter number of row and column: 
   2
   3
   Enter arr [ 0 ] [ 0] : 1
   Enter arr [ 0 ] [ 1] : 2
   Enter arr [ 0 ] [ 2] : 3

   Enter arr [ 1 ] [ 0] : 4
   Enter arr [ 1 ] [ 1] : 5
   Enter arr [ 1 ] [ 2] : 6
   
   Expected Output:
   Largest element in array is 6 and its index position is arr [ 1 ] [ 2 ]  

*/
import java.util.Scanner;

public class TwoDimentionalArray 
{
public static void main(String args[]){

//Declare the variables
Scanner sc=new Scanner(System.in);
//Declare the variables
System.out.println("Enter number of  rows:");
int row=sc.nextInt();
System.out.println("Enter number of  coloumns:");
int coloumn=sc.nextInt();
int[][] array=new int[row][coloumn];
int max=array[0][0];
int[] maxIndex = {0,0};

//Take input from user to enter rows and column values
for(int i=0;i<row;i++)
{
    for(int j=0;j<coloumn;j++)
    {
        System.out.print("Elements ["+i+"]["+j+"] : ");
        array[i][j]=sc.nextInt();
    }
System.out.println(" ");
}
for(int i=0;i<row;i++)
{
    for(int j=0;j<coloumn;j++)
    {
        if(array[i][j]>max)
        {
            max=array[i][j];
            //pos=[i][j];
            maxIndex[0] = i;
             maxIndex[1] = j;
            //System.out.println("Maximum Element positon : "+max);
        }
    } 
    }
}