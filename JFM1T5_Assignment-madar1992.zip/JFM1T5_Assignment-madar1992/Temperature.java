/* JFM1T5_Assignment3:

   Write a program to store the temperature of your city for last 7 days and print the lowest temperature of the week.
   Prompt the user input from the terminal.
   
   Sample Input:
   Enter number of days 
   3
   Enter the temperature of Day :1
   88
   Enter the temperature of Day :2
   34
   Enter the temperature of Day :3
   0 
   
   Expected Output:
   The lowest temperature of the week 3 is 0.0 celsius

*/
import java.util.Scanner;

public class Temperature{

//Define the main method
public static void main(String[] args){
  Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of an days :");
        int numOfDays=sc.nextInt();
        float [] temp=new float[numOfDays];
        float low=0;
        for(int i=0;i<numOfDays;i++){
            System.out.println("Enter the temperature Day:"+(i+1));
            temp[i]=sc.nextFloat();
            
        }
        sc.close();
        low=temp[0];

        for(int i=0;i<temp.length;i++)
        {
            //System.out.println(temp[i]);
            
            if(temp[i]<low)
            {
            low=temp[i];
            }
            //System.out.println("The lowest temperature :"+low);
           
        }
System.out.println("The lowest temperature :"+low);
}
}
