/* JFM1T7_Assignment2:

   Create a Student Result Processing System for 3 students.
   
   Sample inputs: Console input roll numbers, names and 5 subject marks for each student
   
   Sample output: Display roll numbers, names and percentage obtained by all 3 students in the following format:
   Roll Number: 1
   Name: Shree Balaji
   Percentage: 99%

*/




import java.util.Scanner;
import java.util.stream.*;
public class StudentResult {

   //main method
   public static void main(String[] args){
      //initialize student constructor 3 times with different names
      Student s1=new Student();
      Student s2=new Student();
      Student s3=new Student();
      //Create an array and add the 3 student to it
      Student[] stu=new Student[3];
      stu[0]=s1;
      stu[1]=s2;
      stu[2]=s3;
      Scanner sn=new Scanner(System.in);
      for(int i=0;i<stu.length;i++){
        System.out.println("Enter Student "+(i+1)+ " name:");
        stu[i].name=sn.nextLine();
        System.out.println("Enter Student "+(i+1)+" Roll No:");
        stu[i].rollnum=sn.nextInt();
        for(int j=0;j<5;j++){
            System.out.println("Enter subject "+(j+1)+" Marks:");
            stu[i].arr[j]=sn.nextInt();
        }
      }
      for(int i=0;i<stu.length;i++){
         stu[i].getDetails(stu[i].name,stu[i].rollnum,stu[i].arr);
      }
   }
}

//create Student class 
class Student {

//declare and initialize variables
int rollnum;
int arr[]=new int[5];
String name;
Student(){
}
//add getters and setters method
void getDetails(String name,int rollnum,int arr[]){
   this.rollnum=rollnum;
   this.name=name;
   this.arr=arr;
   //display student details
   System.out.println("<======Student Details======>");
   System.out.println("Roll No:"+rollnum);
   System.out.println("Name:"+name);
   //print 5 subject marks using for loop
   for(int i=0;i<arr.length;i++){
      System.out.println("Subject " +(i+1)+ " Marks of Student "+" is:"+arr[i]);
   }
   int sum = IntStream.of(arr).sum();
   displayPercentage(sum);
}
   //create displayPercentage static method in that add a for loop for student array
   public static void displayPercentage(int sum){
      //calculate percentage
      double percentage=((double)sum/500)*100;
      System.out.println("Percentage is:"+percentage+"%");
   }
}