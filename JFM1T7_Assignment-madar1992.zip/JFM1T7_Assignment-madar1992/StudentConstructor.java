/* JFM1T7_Assignment1:

   Write a program to initialize data members of Student class using constructor.
   Prompt the user for the  values to be input from the terminal

   Sample Input:
   Enter student name: Shree Balaji
   Enter student Roll no: 01

   Expected Output:
   Name: Shree Balaji    Roll no: 01

*/



import java.util.Scanner;
public class StudentConstructor {

    //main method
    public static void main(String[] args){
        Scanner sn=new Scanner(System.in);
        //Get student name and rollno from user and set it to the Student object  
        System.out.print("Enter Student Name:");
        String sname=sn.nextLine();
        System.out.print("Enter Student Rollno:");
        int rollNo=sn.nextInt();
        //initialize Student class using constructor
        Student s1=new Student(rollNo,sname);
    }
}

//Create Student class in that declare variables name and roll number 
class Student{
    //add  setter method for rollno
    String name;
    int rollNo;
    Student(int roll,String stname){
        setRollNo(roll);
        int rollnum=getRollNo();
        setName(stname);
        String student_name=getName();
        //print result
        System.out.println("Name:"+student_name+"\tRoll no:"+rollnum);
        
    }
    public void setRollNo(int rollNum){ 
            this.rollNo = rollNum; 
    } 

    //add getter method for rollno
    public int getRollNo(){ 
        return this.rollNo; 
    }

    //add setters and getters for name fields also
    public void setName(String sname){ 
            this.name = sname; 
    } 

    //add getter method for rollno
    public String getName(){ 
        return this.name; 
    }
}