package package1;
public class demo{
    protected void protectedMethod(){
        System.out.println("Try to access the protected method outside the package using inheritance");
        
    }
}