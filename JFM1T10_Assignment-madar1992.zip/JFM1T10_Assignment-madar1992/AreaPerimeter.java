/* JFM1T10_Assignment3:

     Create an abstract class Shape with following data member and methods- 
     Create data members for height and width.
     Add getter and setter methods for height and width.
     Create methods for finding area and perimeter.
     Create three subclasses Square, Rectangle and EquilateralTriangle that extends Shape class and define both the methods.
     Write a program that will find the area and perimeter of 3 Shapes and print the details for all. 
     Prompt the user for the  values to be input from the terminal.
 
     Sample Input:
     Enter Width of Rectangle in meters
     10
     Enter Length of Rectangle in meters
     5
     Enter width of Equilateraltriangle
     15
     Enter radius of circle
     60

     Expected Output:
     Rectangle width: 10.0 meters and length: 5.0 meters
     Resulting area: 50.0 square meters
     Resulting perimeter: 30.0 meters 

     EquiTriangle side: 15.0meters
     Resulting area: 97 square meters
     Resulting perimeter: 45.0 meters 

     Circle radius : 60.0meters
     Resulting area: 11310 square meters
     Resulting perimeter: 377 meters  

*/
// importing a library
import java.util.Scanner;

abstract class Shape{
     
     double width,length;
     double radius,side;
     
     abstract public void area();
     abstract public void perimeter();
}

//Add Rectangle class that extends Shape class
class Rectangle extends Shape{
     void setValues(double width,double length){
          this.width=width;
          this.length=length;
     }
     public void area(){
          System.out.println("Resulting area: "+width*length+" Square Meters");
     }
     public void perimeter(){
          System.out.println("Resulting Perimeter: "+ 2*(width+length)+" Meters");
     }
}
//Add EquilateralTriangle class that extends Shape class
class EquilateralTriangle extends Shape{
     void setValues(double side){
          this.side=side;
     }
     public void area(){
          System.out.println("Triangle area: "+(0.5*side*side)+" Square Meters");
     }
     public void perimeter(){
          System.out.println("Triangle Perimeter: "+ 3*side+" Meters");
     }
}
//Add Circle class that extends Shape class
class Circle extends Shape{
     void setValues(double radius){
          this.radius=radius;
     }
     public void area(){
          System.out.println("Circle area: "+(int)(radius*radius*Math.PI)+" Square Meters");
     }
     public void perimeter(){
          System.out.println("Circle Perimeter: "+(int)(2*Math.PI*radius)+" Meters");
     }
}
public class AreaPerimeter {

     //Add the main method here and find Area and Perimeter 
     public static void main(String args[]){
          //Use the scanner class to provide height and width at execution time
          Scanner sc= new Scanner(System.in);
          System.out.println("Enter Width of Rectangle in meters");
          double width=sc.nextDouble();
          System.out.println("Enter Length of Rectangle in meters");
          double length=sc.nextDouble();
          
          Rectangle rec=new Rectangle();
          rec.setValues(width,length);
          
          System.out.println("Enter side of Equilateraltriangle");
          EquilateralTriangle eq=new EquilateralTriangle();
          double side=sc.nextDouble();
          eq.setValues(side);
          
          System.out.println("Enter radius of circle");
          Circle cr=new Circle();
          double radius=sc.nextDouble();
          cr.setValues(radius);
          System.out.println("\n");

          System.out.println("Rectangle width: "+width+" meters and length: "+length+" meters");
          rec.area();
          rec.perimeter();
          System.out.println("\n");
          
          System.out.println("EquiTriangle side: " +side+ " meters");
          eq.area();
          eq.perimeter();
          System.out.println("\n");
          
          System.out.println("Circle radius: "+radius+" meters");
          cr.area();
          cr.perimeter();
     }
}


// Very Good!
