/*   JFM1T10_Assignment2:

     Create a class Animal that has a method makeSound(). 
     Then create two subclasses of Animal class: Horse and Cat that extends Animal class and 
     provide their specific implementation of makeSound() method.

     Sample Output:
     The animal makes a sound
     The Horse says: wee wee
     The Cat says: meow meow

*/
//Add Animal class and Create Sound() method 
class Animal{
     String sound(){
        return "The animal makes a sound";
     }
}
//Add Horse class that extends Animal class
class Horse extends Animal{
     String sound(){
        return "The Horse says: wee wee";
     }
}

//Add Cat class that extends Animal class
class Cat extends Animal{
     String sound(){
          return "The Cat says: meow meow";
     }
}
class  AnimalInheritance {
     
 //Add main method here
     public static void main(String args[]){
     
     //Create all 3 Animal objects and add to an array 
          Animal obj1=new Animal();
          Horse obj2=new Horse();
          Cat obj3=new Cat();
          String a=obj1.sound();
          String b=obj2.sound();
          String c=obj3.sound();
          //Loop over the array and print sound it makes
          
          String[] anArray={a, b, c};
          
          for (int i = 0; i < anArray.length; i++) {
                      
                      System.out.println(anArray[i] + " ");
                  }
                 

     }
}


// Kindly work on the indentation.
// I have done changes as you suggested.
