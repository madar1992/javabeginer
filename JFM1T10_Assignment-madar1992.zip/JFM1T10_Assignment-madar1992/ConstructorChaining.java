/* JFM1T10_Assignment1:

   Write a program to demonstrate Constructor chaining in Java 
   Add atleast 3 constructors

   Sample Output:
   Parent class default constructor
   Child class default constructor
   Parent class one-argument constructor
   Child class one-argument constructor

*/

//parent class
class Demo {
//parent class default constructor
Demo () {
   
   System.out.println("Parent class default constructor");
}
//parent class one argument constructor
Demo(int a) {
   System.out.println("Parent class one-argument constructor");
}
}
//child class
class Child extends Demo {
   Child () {
      
      System.out.println("Child class default constructor");
   }
   //Child class one-argument constructor
   Child (int a) {
      super(10);
      System.out.println("Child class one-argument constructor");
   }
}

public class ConstructorChaining {
   //main method
   public static void main (String args[]) {
      //the instance 
      Child obj =new Child();
      Child obj1=new Child(10);
         }
}

// Kindly check the logic as the excepted output and your output are not same and also work on the indentation.
// I have done changes as you suggested.