/* JFM1T9_Assignment3:
     Create a base class Teacher and a sub class ComputerTeacher.
     class ComputerTeacher extends the designation and collegename properties and work() method from base Teacher class,
     you need not declare these properties and method in ComputerTeacher sub class .
     Try accessing these properties using child class object in Main method.
  
     Sample Output:
     Designation       CollegeName
     ComputerTeacher      IIT
*/

class Teacher {
     // Declaring variables 
     String Designation="collegename";
     String collegename="IIT";
     // creating a method
     public void work() {
          System.out.println("Designation       "+Designation);
          System.out.println("ComputerTeacher       "+collegename);
          
     }
}

class ComputerTeacher {
     // main method
     public static void main(String args[]) {
          // creating an object
          Teacher obj=new Teacher();
          // printing the result
          obj.work();
     }


}



// Very Good!
