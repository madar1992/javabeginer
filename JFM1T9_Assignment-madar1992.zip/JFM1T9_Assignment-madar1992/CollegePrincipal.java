/* JFM1T9_Assignment4:
     Extend and enhance the previous inheritance program where collegeName, designation and 
     work() method are common to all the teachers and declared in the base class in the way
     that all child classes like MathTeacher, EnglishTeacher and MusicTeacher do not need to 
     write this code and can use directly from base class. 

     Sample Output:
     Math Teacher         IIT
     English Teacher      IIT
     Music Teacher        IIT
*/

//Add Teacher class
class Teacher {
     String collegeName="IIT";
     String Designation;
     // creating the method
     public void work(){
         
     System.out.println(Designation+"       "+collegeName);
}
}
//Add MathTeacher class
 class  MathTeacher extends Teacher {
 
}

//Add EnglishTeacher class
 class EnglishTeacher extends Teacher {
    
} 
//Add MusicTeacher class
 class MusicTeacher extends Teacher {
    
}

class CollegePrincipal {

//Add the main method here and create all different types of Teacher objects and print there college name designation.
public static void main(String args[]) {
    String Designation;
    // Creating three different objects for three different teachers
     MathTeacher obj1=new MathTeacher();
     EnglishTeacher obj2= new EnglishTeacher();
     MusicTeacher obj3=new MusicTeacher();
     // initializing designations in objects
     obj1.Designation="Math Teacher";
     obj2.Designation="English Teacher";
     obj3.Designation="Music Teacher";
     // Printing all the results
     obj1.work();
     obj2.work();
     obj3.work();
    }
}


// Kindly work on the indentation.
//I hvae changed indentation.
