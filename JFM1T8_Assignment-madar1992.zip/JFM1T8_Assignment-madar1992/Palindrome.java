/*  JFM1T8_Assignment4:

    Write a program to check whether a string is a Palindrome.
    Prompt the user input from the terminal.
    
    Sample input: Malayalam
    
    Expected output: Malayalam is a Palindrome
*/

import java.util.Scanner;

public class Palindrome {
//main method
public static void main(String args[]){
    
    //declare varible
      String reverse="";
      
    //take input from user
      Scanner in = new Scanner(System.in);   
      System.out.println("Enter a string/number to check if it is a palindrome");  
      String original = in.nextLine();   
      
      int length = original.length();  
     

      for ( int i = length - 1; i >= 0; i-- )  
        reverse = reverse + original.charAt(i);  
         
      if (original.equals(reverse))  
         System.out.println("Entered string/number is a palindrome.");  
         
      else  
         System.out.println("Entered string/number isn't a palindrome.");

}
}