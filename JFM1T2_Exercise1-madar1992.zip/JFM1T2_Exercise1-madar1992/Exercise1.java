// Write a program to print your Name, Father's Name and Mailing Address in different lines

public class Exercise1 {
    public static void main(String args[]){
        
        System.out.println("Hai there\n I am Madarsaheb \n I am son of D Pakeer Saheb \n My mail id is madarsahebdudekula@gmail.com");
    }



} 