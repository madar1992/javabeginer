/*  JFM1T11_Assignment5 :

    Write a program to sort an array containing negative, non-negative and zero values in descending order.
    Prompt the user input from the terminal.
    
    Sample Input: 2,-3,-1,4,-2
    
    Expected Output: -3,-2,-1,4,2
    
*/

import java.util.Scanner;

public class RearrangePositiveNegative {
    
    //create descending method
    public static void descending(int[] arr){
        
    
    //declare and initialize variables
    int j=0;
        
    //check each element if the element is less then zero and the both numbers are not equal  then it swaps them
    for (int i=0; i<arr.length; i++){
        if(arr[i]<0){
            if(j!=i){
                int temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }
            //increasing elements untill all elements rearranged
            j++;
        }
    }    
        
    
    }   

    //main method
    public static void main(String args[]){
        
        //take input from user
        Scanner sc=new Scanner(System.in);  
        System.out.print("Enter the number of elements you want to store: ");  
        //reading the number of elements from the that we want to enter  
        
        int n=sc.nextInt();  
        //creates an array in the memory of length n
        
        int[] array = new int[n];  
        System.out.println("Enter the elements of the array: ");  
        
        for(int i=0; i<n; i++)  
        {  
        //reading array elements from the user   
        array[i]=sc.nextInt();  
        }
        
        //call descending method
        descending(array);
        //print result
        System.out.println("RearrangePositiveNegative in order: ");
        for(int i=0; i<array.length; i++){
            System.out.print(array[i]+",");
        }
  }
       
 
}