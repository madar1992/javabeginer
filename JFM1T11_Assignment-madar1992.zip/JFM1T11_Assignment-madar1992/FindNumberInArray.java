/* JFM1T11_Assignment1:

   Write a program to find a number in an integer array. If found print the number and the array index at which it is found. 
   Prompt the user input from the terminal.
   
   Sample Input: 2,4,6,1,7,8,9
   Enter number to search x= 9

   Expected Output: 9 found at index 6
   
   Enter number to search x= 12
   Expected Output: Sorry! 12 is not found in array.
   
*/
import java.util.Scanner;

public class FindNumberInArray {

   //main method
   public static void main(String args[]){
      //declaring variables
      String s;
      //creating Scanner object
      Scanner sc=new Scanner(System.in);
      //take input from user
      System.out.print("Enter comma Separated intput values: ");
      s=sc.nextLine();
      String str[]=s.split(",");
      int arr[]=new int[str.length];
      int i=0;
      while(i<arr.length){
         arr[i]=Integer.parseInt(str[i]);
         i++;
      }
      //find number in array
      System.out.print("Enter number to search x= ");
      int x=sc.nextInt();
      int j=0,temp=0;
      while(j<arr.length){
         //search the element if found print that position else print not found message
         if(x==arr[j]){
            temp=j;
            break;
         }
         else
            temp=0;
         j++;
      }
      if(temp==0)
        System.out.print("Sorry! "+x+" is not found in array."); 
      else
         System.out.print(x+" found at index of "+j);
   }
}

